-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-05-2026 a las 05:29:33
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ippuptag`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `afiliado`
--

CREATE TABLE `afiliado` (
  `id_afiliado` int(11) NOT NULL,
  `id_agremiado` int(11) DEFAULT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `ci` varchar(20) NOT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `correo` varchar(150) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `fecha_ingreso` date NOT NULL DEFAULT curdate(),
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `cod_a` varchar(50) DEFAULT NULL,
  `cod_pm` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `afiliado`
--

INSERT INTO `afiliado` (`id_afiliado`, `id_agremiado`, `nombre`, `apellido`, `ci`, `fecha_nacimiento`, `correo`, `telefono`, `fecha_ingreso`, `activo`, `cod_a`, `cod_pm`) VALUES
(1, NULL, 'José', 'Ramírez', 'V-12345678', '1985-03-15', 'j.ramirez@uptag.edu.ve', NULL, '2026-05-16', 1, 'UPTAG-2019', 'PM-0042'),
(2, 2, 'María', 'González', 'V-22334455', '1990-07-22', 'm.gonzalez@uptag.edu.ve', NULL, '2026-05-21', 1, NULL, NULL),
(3, 3, 'Carlos', 'Pérez', 'V-33445566', '1978-11-08', 'javierrreyes.02@gmail.com', '04121234567', '2026-05-21', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `agremiado`
--

CREATE TABLE `agremiado` (
  `id_agremiado` int(11) NOT NULL,
  `ci` varchar(20) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `correo` varchar(150) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `fecha_agremiacion` date NOT NULL DEFAULT curdate(),
  `observaciones` text DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `agremiado`
--

INSERT INTO `agremiado` (`id_agremiado`, `ci`, `nombre`, `apellido`, `fecha_nacimiento`, `correo`, `telefono`, `fecha_agremiacion`, `observaciones`, `activo`, `creado_en`, `actualizado_en`) VALUES
(1, 'V-12345678', 'José', 'Ramírez', '1985-03-15', 'j.ramirez@uptag.edu.ve', NULL, '2010-01-15', NULL, 1, '2026-05-19 00:22:45', '2026-05-19 00:22:45'),
(2, 'V-22334455', 'María', 'González', '1990-07-22', 'm.gonzalez@uptag.edu.ve', NULL, '2015-03-01', NULL, 1, '2026-05-19 00:22:45', '2026-05-19 00:22:45'),
(3, 'V-33445566', 'Carlos', 'Pérez', '1978-11-08', 'c.perez@uptag.edu.ve', NULL, '2008-09-10', NULL, 1, '2026-05-19 00:22:45', '2026-05-19 00:22:45'),
(4, 'V-44556677', 'Ana', 'Torres', '1995-02-14', 'a.torres@uptag.edu.ve', NULL, '2020-06-05', NULL, 1, '2026-05-19 00:22:45', '2026-05-19 00:22:45'),
(5, 'V-55667788', 'Luis', 'Medina', '1982-05-30', 'l.medina@uptag.edu.ve', NULL, '2012-02-20', NULL, 1, '2026-05-19 00:22:45', '2026-05-19 00:22:45');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `beneficiario`
--

CREATE TABLE `beneficiario` (
  `id_beneficiario` int(11) NOT NULL,
  `numero_beneficiario` int(11) NOT NULL,
  `ci` varchar(20) DEFAULT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `parentesco` varchar(50) DEFAULT NULL,
  `id_afiliado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `beneficiario`
--

INSERT INTO `beneficiario` (`id_beneficiario`, `numero_beneficiario`, `ci`, `nombre`, `apellido`, `fecha_nacimiento`, `parentesco`, `id_afiliado`) VALUES
(1, 1, 'V-14222333', 'Ana', 'Ramírez', '1987-06-20', 'Cónyuge', 1),
(2, 2, NULL, 'Carlos', 'Ramírez', '2012-09-10', 'Hijo', 1),
(3, 3, NULL, 'Laura', 'Ramírez', '2015-02-28', 'Hija', 1),
(4, 1, 'V-22334455', 'María', 'González', '1990-07-22', 'Titular', 2),
(5, 1, 'V-33445566', 'Carlos', 'Pérez', '1978-11-08', 'Titular', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carta_aval`
--

CREATE TABLE `carta_aval` (
  `id_carta` int(11) NOT NULL,
  `medico_tratante` varchar(150) NOT NULL,
  `especialidad` varchar(100) DEFAULT NULL,
  `centro_medico` varchar(150) NOT NULL,
  `procedimiento` text DEFAULT NULL,
  `monto_estimado` decimal(12,2) DEFAULT NULL,
  `estado` varchar(30) NOT NULL DEFAULT 'pendiente',
  `fecha_solicitud` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_vencimiento` date DEFAULT NULL,
  `id_afiliado` int(11) NOT NULL,
  `id_beneficiario` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `carta_aval`
--

INSERT INTO `carta_aval` (`id_carta`, `medico_tratante`, `especialidad`, `centro_medico`, `procedimiento`, `monto_estimado`, `estado`, `fecha_solicitud`, `fecha_vencimiento`, `id_afiliado`, `id_beneficiario`) VALUES
(1, 'Dr. Carlos González', 'Cardiología', 'Policlínica Los Llanos', 'Consulta cardiológica', 1200.00, 'aprobada', '2026-05-17 19:20:23', NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuenta_web`
--

CREATE TABLE `cuenta_web` (
  `id_cuenta` int(11) NOT NULL,
  `id_agremiado` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `correo_verificado` tinyint(1) NOT NULL DEFAULT 0,
  `ultimo_acceso` timestamp NULL DEFAULT NULL,
  `intentos_fallidos` tinyint(4) NOT NULL DEFAULT 0,
  `bloqueado` tinyint(1) NOT NULL DEFAULT 0,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cuenta_web`
--

INSERT INTO `cuenta_web` (`id_cuenta`, `id_agremiado`, `username`, `password_hash`, `correo_verificado`, `ultimo_acceso`, `intentos_fallidos`, `bloqueado`, `creado_en`) VALUES
(7, 2, 'V-22334455', '$2y$12$KIaDCTZsYVrKtUpjZ4xnoOaAY9Bl6W6nYOc.Cnyj.vCb7C4epX/.C', 0, NULL, 0, 0, '2026-05-21 13:22:39'),
(8, 3, 'V-33445566', '$2y$12$jWO8Qz0PWSDyrehWsc8fS.CPNdVi/RcPTF.UnJMUzp8/U1rkhRYWS', 0, NULL, 0, 0, '2026-05-22 02:05:56');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ipp_lutag`
--

CREATE TABLE `ipp_lutag` (
  `cod_a` varchar(50) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ipp_lutag`
--

INSERT INTO `ipp_lutag` (`cod_a`, `id`) VALUES
('UPTAG-2019', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `log_actividad`
--

CREATE TABLE `log_actividad` (
  `id_log` int(11) NOT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `accion` varchar(60) NOT NULL,
  `detalle` varchar(255) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `log_actividad`
--

INSERT INTO `log_actividad` (`id_log`, `id_usuario`, `accion`, `detalle`, `ip`, `fecha`) VALUES
(1, 1, 'login', 'Inicio de sesión', '::1', '2026-05-19 00:35:26'),
(2, 1, 'logout', 'Cierre de sesión', '::1', '2026-05-19 00:36:08'),
(3, NULL, 'login', 'Inicio de sesión', '::1', '2026-05-19 00:47:43'),
(4, NULL, 'usuario_creado', 'Usuario \'13496095\' creado con rol afiliado', '::1', '2026-05-19 01:42:25'),
(5, NULL, 'logout', 'Cierre de sesión', '::1', '2026-05-19 01:42:49'),
(6, 7, 'login', 'Inicio de sesión', '::1', '2026-05-19 01:47:47'),
(7, 7, 'logout', 'Cierre de sesión', '::1', '2026-05-20 02:10:05'),
(8, NULL, 'login', 'Inicio de sesión', '::1', '2026-05-20 02:10:16'),
(9, NULL, 'reembolso_aprobado', 'Reembolso #2 aprobado', '::1', '2026-05-20 02:11:44'),
(10, NULL, 'reembolso_aprobado', 'Reembolso #1 aprobado', '::1', '2026-05-20 02:11:46'),
(11, NULL, 'logout', 'Cierre de sesión', '::1', '2026-05-20 02:15:21'),
(12, 7, 'login', 'Inicio de sesión', '::1', '2026-05-20 02:22:18'),
(13, 7, 'cambio_password', 'El usuario cambió su contraseña', '::1', '2026-05-20 02:22:42'),
(14, 7, 'logout', 'Cierre de sesión', '::1', '2026-05-20 02:22:57'),
(15, 1, 'login', 'Inicio de sesión', '::1', '2026-05-20 02:23:07'),
(16, 1, 'cambio_password', 'El usuario cambió su contraseña', '::1', '2026-05-20 02:23:36'),
(17, 1, 'logout', 'Cierre de sesión', '::1', '2026-05-21 02:13:24'),
(18, NULL, 'login', 'Inicio de sesión', '::1', '2026-05-21 12:26:58'),
(19, NULL, 'logout', 'Cierre de sesión', '::1', '2026-05-21 12:28:15'),
(20, 13, 'login', 'Inicio de sesión', '::1', '2026-05-21 12:29:57'),
(21, 13, 'logout', 'Cierre de sesión', '::1', '2026-05-21 12:30:23'),
(22, 12, 'login', 'Inicio de sesión', '::1', '2026-05-21 12:30:31'),
(23, 12, 'usuario_desactivado', 'Usuario #1', '::1', '2026-05-21 12:30:40'),
(24, 12, 'usuario_activado', 'Usuario #1', '::1', '2026-05-21 12:30:48'),
(25, 12, 'logout', 'Cierre de sesión', '::1', '2026-05-21 12:31:42'),
(26, NULL, 'solicitud_registro', 'Solicitud de registro para CI: V-22334455', '::1', '2026-05-21 12:32:41'),
(27, 12, 'login', 'Inicio de sesión', '::1', '2026-05-21 12:40:53'),
(28, 12, 'logout', 'Cierre de sesión', '::1', '2026-05-21 12:43:10'),
(29, 13, 'login', 'Inicio de sesión', '::1', '2026-05-21 12:43:20'),
(30, 13, 'logout', 'Cierre de sesión', '::1', '2026-05-21 12:44:38'),
(31, 12, 'login', 'Inicio de sesión', '::1', '2026-05-21 12:44:48'),
(32, 12, 'logout', 'Cierre de sesión', '::1', '2026-05-21 12:48:08'),
(33, 12, 'login', 'Inicio de sesión', '::1', '2026-05-21 12:48:34'),
(34, 12, 'logout', 'Cierre de sesión', '::1', '2026-05-21 12:48:49'),
(35, 12, 'login', 'Inicio de sesión', '::1', '2026-05-21 13:08:31'),
(36, 12, 'logout', 'Cierre de sesión', '::1', '2026-05-21 13:08:36'),
(37, NULL, 'registro_nuevo', 'Registro directo CI: V-22334455', '::1', '2026-05-21 13:22:39'),
(38, 20, 'login', 'Inicio de sesión', '::1', '2026-05-21 13:22:58'),
(39, 20, 'logout', 'Cierre de sesión', '::1', '2026-05-21 16:50:25'),
(40, 20, 'login', 'Inicio de sesión', '::1', '2026-05-21 19:59:44'),
(41, 20, 'logout', 'Cierre de sesión', '::1', '2026-05-21 20:23:35'),
(42, 20, 'login', 'Inicio de sesión', '::1', '2026-05-21 20:23:45'),
(43, 20, 'logout', 'Cierre de sesión', '::1', '2026-05-21 20:27:54'),
(44, 20, 'login', 'Inicio de sesión', '::1', '2026-05-21 20:28:05'),
(45, 20, 'logout', 'Cierre de sesión', '::1', '2026-05-21 20:31:33'),
(46, 20, 'login', 'Inicio de sesión', '::1', '2026-05-21 20:37:02'),
(47, 20, 'logout', 'Cierre de sesión', '::1', '2026-05-21 20:45:56'),
(48, 20, 'login', 'Inicio de sesión', '::1', '2026-05-21 20:46:19'),
(49, 20, 'logout', 'Cierre de sesión', '::1', '2026-05-21 21:18:03'),
(50, 20, 'login', 'Inicio de sesión', '::1', '2026-05-21 21:18:15'),
(51, 20, 'logout', 'Cierre de sesión', '::1', '2026-05-22 01:45:11'),
(52, NULL, 'registro_nuevo', 'Registro directo CI: V-33445566', '::1', '2026-05-22 02:05:56'),
(53, 21, 'login', 'Inicio de sesión', '::1', '2026-05-22 02:06:11'),
(54, 21, 'reembolso_solicitado', 'Reembolso Consulta médica por Bs. 20000', '::1', '2026-05-22 02:06:55'),
(55, 21, 'logout', 'Cierre de sesión', '::1', '2026-05-22 02:15:19'),
(56, 21, 'login', 'Inicio de sesión', '::1', '2026-05-22 02:55:11'),
(57, 21, 'reembolso_solicitado', 'Reembolso Hospitalización por Bs. 70000', '::1', '2026-05-22 02:56:18'),
(58, 21, 'logout', 'Cierre de sesión', '::1', '2026-05-22 03:04:18'),
(59, 12, 'login', 'Inicio de sesión', '::1', '2026-05-22 03:25:14'),
(60, 12, 'logout', 'Cierre de sesión', '::1', '2026-05-22 03:26:09'),
(61, 21, 'login', 'Inicio de sesión', '::1', '2026-05-22 03:26:21');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `medico`
--

CREATE TABLE `medico` (
  `id_medico` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `especialidad` varchar(100) NOT NULL,
  `cedula` varchar(20) NOT NULL,
  `numero_contacto` varchar(20) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `id_servicio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `medico`
--

INSERT INTO `medico` (`id_medico`, `nombre`, `apellido`, `especialidad`, `cedula`, `numero_contacto`, `fecha_nacimiento`, `id_servicio`) VALUES
(1, 'Carlos', 'González', 'Cardiología', 'V-9876543', '0255-621-0000', NULL, 1),
(2, 'María', 'Ortega', 'Pediatría', 'V-8765432', '0426-333-0002', NULL, 1),
(3, 'Luis', 'Páez', 'Traumatología', 'V-7654321', '0255-621-0003', NULL, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimiento_cuenta`
--

CREATE TABLE `movimiento_cuenta` (
  `id_movimiento` int(11) NOT NULL,
  `fecha` date NOT NULL DEFAULT curdate(),
  `concepto` varchar(200) NOT NULL,
  `tipo` enum('credito','debito') NOT NULL,
  `monto` decimal(12,2) NOT NULL,
  `saldo_despues` decimal(12,2) NOT NULL DEFAULT 0.00,
  `id_afiliado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `movimiento_cuenta`
--

INSERT INTO `movimiento_cuenta` (`id_movimiento`, `fecha`, `concepto`, `tipo`, `monto`, `saldo_despues`, `id_afiliado`) VALUES
(1, '2026-05-01', 'Aporte patronal Mayo', 'credito', 4150.00, 84200.00, 1),
(2, '2026-05-01', 'Aporte individual Mayo', 'credito', 2075.00, 80050.00, 1),
(3, '2026-04-15', 'Intereses trimestrales', 'credito', 1240.00, 77975.00, 1),
(4, '2026-04-01', 'Aporte patronal Abril', 'credito', 4150.00, 76735.00, 1),
(5, '2026-03-10', 'Retiro parcial aprobado', 'debito', 5000.00, 72585.00, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `plan_medico`
--

CREATE TABLE `plan_medico` (
  `cod_pm` varchar(50) NOT NULL,
  `costo` decimal(10,2) NOT NULL DEFAULT 0.00,
  `id_plan` int(11) NOT NULL,
  `cod_a` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `plan_medico`
--

INSERT INTO `plan_medico` (`cod_pm`, `costo`, `id_plan`, `cod_a`) VALUES
('PM-0042', 1800.00, 42, 'UPTAG-2019');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recuperacion_password`
--

CREATE TABLE `recuperacion_password` (
  `id_recuperacion` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expira_en` datetime NOT NULL,
  `usado` tinyint(1) NOT NULL DEFAULT 0,
  `ip_solicitud` varchar(45) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reembolso`
--

CREATE TABLE `reembolso` (
  `id_reembolso` int(11) NOT NULL,
  `tipo_servicio` varchar(100) NOT NULL,
  `fecha_atencion` date NOT NULL,
  `monto_solicitado` decimal(12,2) NOT NULL,
  `monto_aprobado` decimal(12,2) DEFAULT NULL,
  `centro_medico` varchar(150) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `archivo_adjunto` varchar(255) DEFAULT NULL,
  `estado` varchar(30) NOT NULL DEFAULT 'pendiente',
  `fecha_solicitud` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_resolucion` timestamp NULL DEFAULT NULL,
  `id_afiliado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `reembolso`
--

INSERT INTO `reembolso` (`id_reembolso`, `tipo_servicio`, `fecha_atencion`, `monto_solicitado`, `monto_aprobado`, `centro_medico`, `descripcion`, `archivo_adjunto`, `estado`, `fecha_solicitud`, `fecha_resolucion`, `id_afiliado`) VALUES
(1, 'Medicamentos', '2026-05-10', 850.00, 850.00, 'Farmacia UPTAG', NULL, NULL, 'aprobado', '2026-05-17 19:20:23', '2026-05-20 02:11:46', 1),
(2, 'Consulta médica', '2026-05-02', 400.00, 400.00, 'Policlínica Los Llanos', NULL, NULL, 'aprobado', '2026-05-17 19:20:23', '2026-05-20 02:11:44', 1),
(3, 'Exámenes', '2026-04-15', 1200.00, NULL, 'Lab. Clínico Central', NULL, NULL, 'aprobado', '2026-05-17 19:20:23', NULL, 1),
(4, 'Dental', '2026-05-18', 15000.00, NULL, 'Clinica Lomas Turbas', 'extraccion de muela', NULL, 'pendiente', '2026-05-20 02:25:28', NULL, 1),
(5, 'Consulta médica', '2026-05-18', 20000.00, NULL, 'Clinica Lomas Turbas', 'asnckjanjkcnakcjnakjcnakcjnsjkcnakjcnsa', 'reemb_3_20260522040655_774002e2.png', 'pendiente', '2026-05-22 02:06:55', NULL, 3),
(6, 'Hospitalización', '2026-05-18', 70000.00, NULL, 'Clinica Lomas Turbas', 'tarararara tan tan', 'reemb_3_20260522045618_e016b457.png', 'pendiente', '2026-05-22 02:56:18', NULL, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicio`
--

CREATE TABLE `servicio` (
  `id_servicio` int(11) NOT NULL,
  `tipo_servicio` varchar(100) NOT NULL,
  `cod_pm` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `servicio`
--

INSERT INTO `servicio` (`id_servicio`, `tipo_servicio`, `cod_pm`) VALUES
(1, 'Ambulatorio', 'PM-0042'),
(2, 'Hospitalario', 'PM-0042'),
(3, 'Dental', 'PM-0042'),
(4, 'Farmacia', 'PM-0042');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitud_registro`
--

CREATE TABLE `solicitud_registro` (
  `id_solicitud` int(11) NOT NULL,
  `ci` varchar(20) NOT NULL,
  `correo_contacto` varchar(150) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `estado` enum('pendiente','aprobada','rechazada') NOT NULL DEFAULT 'pendiente',
  `motivo_rechazo` varchar(255) DEFAULT NULL,
  `procesado_por` int(11) DEFAULT NULL,
  `fecha_solicitud` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_resolucion` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `solicitud_registro`
--

INSERT INTO `solicitud_registro` (`id_solicitud`, `ci`, `correo_contacto`, `telefono`, `password_hash`, `estado`, `motivo_rechazo`, `procesado_por`, `fecha_solicitud`, `fecha_resolucion`) VALUES
(1, 'V-22334455', 'mariaperz@gmail.com', '04121234567', '$2y$12$xjg6HRcv9Pom1Fp4As2W/uHKrHpl4iOe7b.6aB41byAPpSIhgVDde', 'pendiente', NULL, NULL, '2026-05-21 12:32:41', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitud_retiro`
--

CREATE TABLE `solicitud_retiro` (
  `id_retiro` int(11) NOT NULL,
  `id_afiliado` int(11) NOT NULL,
  `tipo_retiro` enum('Parcial','Total') NOT NULL DEFAULT 'Parcial',
  `monto` decimal(12,2) NOT NULL,
  `motivo` text DEFAULT NULL,
  `estado` enum('pendiente','aprobado','rechazado') NOT NULL DEFAULT 'pendiente',
  `procesado_por` int(11) DEFAULT NULL,
  `fecha_solicitud` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_resolucion` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios_registrados`
--

CREATE TABLE `usuarios_registrados` (
  `id_usuario` int(11) NOT NULL,
  `username` varchar(80) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `rol` varchar(30) NOT NULL DEFAULT 'afiliado',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `ultimo_acceso` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `id_afiliado` int(11) DEFAULT NULL,
  `cod_a` varchar(50) DEFAULT NULL,
  `intentos_fallidos` tinyint(4) NOT NULL DEFAULT 0,
  `bloqueado` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios_registrados`
--

INSERT INTO `usuarios_registrados` (`id_usuario`, `username`, `password_hash`, `rol`, `activo`, `ultimo_acceso`, `creado_en`, `id_afiliado`, `cod_a`, `intentos_fallidos`, `bloqueado`) VALUES
(1, 'V-12345678', '$2y$12$OyV4DxHEB/i3D6DCwYgNe.NA1Rq6ZqEBFUb7bjmB3i7sKjuNp1F46', 'afiliado', 1, '2026-05-22 03:24:58', '2026-05-17 03:53:09', 1, 'UPTAG-2019', 3, 1),
(7, '13496095', '$2y$12$JBjTv5OD9hY7mHWOsxOFH.WBdEsNZ0lyTSNt0/74kNdgN3xprH0jC', 'afiliado', 1, '2026-05-20 02:22:42', '2026-05-19 01:42:25', NULL, NULL, 0, 0),
(12, 'admin', '$2y$12$NDWfQbXtNImk4gQt5hq2L.CKib0qNEECo.pSbnRuPpUafEV4/zeZa', 'admin', 1, '2026-05-22 03:25:14', '2026-05-21 12:29:10', NULL, NULL, 0, 0),
(13, 'administrativo', '$2y$12$NDWfQbXtNImk4gQt5hq2L.CKib0qNEECo.pSbnRuPpUafEV4/zeZa', 'administrativo', 1, '2026-05-21 16:51:25', '2026-05-21 12:29:10', NULL, NULL, 0, 0),
(20, 'V-22334455', '$2y$12$KIaDCTZsYVrKtUpjZ4xnoOaAY9Bl6W6nYOc.Cnyj.vCb7C4epX/.C', 'afiliado', 1, '2026-05-22 02:00:53', '2026-05-21 13:22:39', 2, NULL, 0, 0),
(21, 'V-33445566', '$2y$12$jWO8Qz0PWSDyrehWsc8fS.CPNdVi/RcPTF.UnJMUzp8/U1rkhRYWS', 'afiliado', 1, '2026-05-22 03:26:21', '2026-05-22 02:05:56', 3, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vigencia_anual`
--

CREATE TABLE `vigencia_anual` (
  `id_vigencia` int(11) NOT NULL,
  `id_agremiado` int(11) NOT NULL,
  `anio` year(4) NOT NULL,
  `fecha_registro` date NOT NULL DEFAULT curdate(),
  `fecha_vencimiento` date NOT NULL,
  `estado` enum('activa','vencida','suspendida') NOT NULL DEFAULT 'activa',
  `registrado_por` int(11) DEFAULT NULL,
  `observaciones` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `vigencia_anual`
--

INSERT INTO `vigencia_anual` (`id_vigencia`, `id_agremiado`, `anio`, `fecha_registro`, `fecha_vencimiento`, `estado`, `registrado_por`, `observaciones`) VALUES
(1, 2, '2026', '2026-05-21', '2026-12-31', 'activa', NULL, NULL),
(2, 3, '2026', '2026-05-21', '2026-12-31', 'activa', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_estado_agremiado`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_estado_agremiado` (
`id_agremiado` int(11)
,`ci` varchar(20)
,`nombre` varchar(100)
,`apellido` varchar(100)
,`agremiado_activo` tinyint(1)
,`fecha_agremiacion` date
,`tiene_cuenta_web` int(1)
,`username` varchar(100)
,`bloqueado` tinyint(1)
,`anio_vigencia` year(4)
,`estado_vigencia` enum('activa','vencida','suspendida')
,`fecha_vencimiento` date
,`estado_general` varchar(21)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `v_estado_agremiado`
--
DROP TABLE IF EXISTS `v_estado_agremiado`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_estado_agremiado`  AS SELECT `a`.`id_agremiado` AS `id_agremiado`, `a`.`ci` AS `ci`, `a`.`nombre` AS `nombre`, `a`.`apellido` AS `apellido`, `a`.`activo` AS `agremiado_activo`, `a`.`fecha_agremiacion` AS `fecha_agremiacion`, `c`.`id_cuenta` is not null AS `tiene_cuenta_web`, `c`.`username` AS `username`, `c`.`bloqueado` AS `bloqueado`, `v`.`anio` AS `anio_vigencia`, `v`.`estado` AS `estado_vigencia`, `v`.`fecha_vencimiento` AS `fecha_vencimiento`, CASE WHEN `a`.`activo` = 0 THEN 'Inactivo' WHEN `c`.`id_cuenta` is null THEN 'Sin cuenta web' WHEN `c`.`bloqueado` = 1 THEN 'Cuenta bloqueada' WHEN `v`.`id_vigencia` is null THEN 'Sin vigencia este año' WHEN `v`.`estado` = 'activa' THEN 'Activo' WHEN `v`.`estado` = 'vencida' THEN 'Vigencia vencida' ELSE 'Suspendido' END AS `estado_general` FROM ((`agremiado` `a` left join `cuenta_web` `c` on(`c`.`id_agremiado` = `a`.`id_agremiado`)) left join `vigencia_anual` `v` on(`v`.`id_agremiado` = `a`.`id_agremiado` and `v`.`anio` = year(curdate()))) ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `afiliado`
--
ALTER TABLE `afiliado`
  ADD PRIMARY KEY (`id_afiliado`),
  ADD UNIQUE KEY `ci` (`ci`),
  ADD UNIQUE KEY `correo` (`correo`),
  ADD KEY `cod_a` (`cod_a`),
  ADD KEY `idx_afiliado_ci` (`ci`),
  ADD KEY `idx_afiliado_cod_pm` (`cod_pm`);

--
-- Indices de la tabla `agremiado`
--
ALTER TABLE `agremiado`
  ADD PRIMARY KEY (`id_agremiado`),
  ADD UNIQUE KEY `ci` (`ci`),
  ADD KEY `idx_agremiado_ci` (`ci`);

--
-- Indices de la tabla `beneficiario`
--
ALTER TABLE `beneficiario`
  ADD PRIMARY KEY (`id_beneficiario`),
  ADD UNIQUE KEY `ci` (`ci`),
  ADD UNIQUE KEY `uk_afiliado_ci` (`id_afiliado`,`ci`),
  ADD KEY `idx_beneficiario_af` (`id_afiliado`);

--
-- Indices de la tabla `carta_aval`
--
ALTER TABLE `carta_aval`
  ADD PRIMARY KEY (`id_carta`),
  ADD KEY `id_beneficiario` (`id_beneficiario`),
  ADD KEY `idx_carta_af` (`id_afiliado`),
  ADD KEY `idx_carta_aval_estado` (`estado`);

--
-- Indices de la tabla `cuenta_web`
--
ALTER TABLE `cuenta_web`
  ADD PRIMARY KEY (`id_cuenta`),
  ADD UNIQUE KEY `id_agremiado` (`id_agremiado`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `idx_cuenta_username` (`username`);

--
-- Indices de la tabla `ipp_lutag`
--
ALTER TABLE `ipp_lutag`
  ADD PRIMARY KEY (`cod_a`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indices de la tabla `log_actividad`
--
ALTER TABLE `log_actividad`
  ADD PRIMARY KEY (`id_log`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `idx_log_fecha` (`fecha`);

--
-- Indices de la tabla `medico`
--
ALTER TABLE `medico`
  ADD PRIMARY KEY (`id_medico`),
  ADD UNIQUE KEY `cedula` (`cedula`),
  ADD KEY `idx_medico_servicio` (`id_servicio`);

--
-- Indices de la tabla `movimiento_cuenta`
--
ALTER TABLE `movimiento_cuenta`
  ADD PRIMARY KEY (`id_movimiento`),
  ADD KEY `idx_mov_afiliado` (`id_afiliado`),
  ADD KEY `idx_mov_fecha` (`fecha`);

--
-- Indices de la tabla `plan_medico`
--
ALTER TABLE `plan_medico`
  ADD PRIMARY KEY (`cod_pm`),
  ADD UNIQUE KEY `id_plan` (`id_plan`),
  ADD KEY `cod_a` (`cod_a`);

--
-- Indices de la tabla `recuperacion_password`
--
ALTER TABLE `recuperacion_password`
  ADD PRIMARY KEY (`id_recuperacion`),
  ADD UNIQUE KEY `token` (`token`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `idx_recuperacion_token` (`token`),
  ADD KEY `idx_recuperacion_expira` (`expira_en`);

--
-- Indices de la tabla `reembolso`
--
ALTER TABLE `reembolso`
  ADD PRIMARY KEY (`id_reembolso`),
  ADD KEY `idx_reembolso_af` (`id_afiliado`),
  ADD KEY `idx_reembolso_estado` (`estado`),
  ADD KEY `idx_reembolso_afiliado` (`id_afiliado`);

--
-- Indices de la tabla `servicio`
--
ALTER TABLE `servicio`
  ADD PRIMARY KEY (`id_servicio`),
  ADD KEY `idx_servicio_plan` (`cod_pm`);

--
-- Indices de la tabla `solicitud_registro`
--
ALTER TABLE `solicitud_registro`
  ADD PRIMARY KEY (`id_solicitud`),
  ADD KEY `procesado_por` (`procesado_por`),
  ADD KEY `idx_solicitud_ci` (`ci`),
  ADD KEY `idx_solicitud_estado` (`estado`);

--
-- Indices de la tabla `solicitud_retiro`
--
ALTER TABLE `solicitud_retiro`
  ADD PRIMARY KEY (`id_retiro`),
  ADD KEY `id_afiliado` (`id_afiliado`),
  ADD KEY `procesado_por` (`procesado_por`);

--
-- Indices de la tabla `usuarios_registrados`
--
ALTER TABLE `usuarios_registrados`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `id_afiliado` (`id_afiliado`),
  ADD KEY `cod_a` (`cod_a`),
  ADD KEY `idx_usuario_afiliado` (`id_afiliado`);

--
-- Indices de la tabla `vigencia_anual`
--
ALTER TABLE `vigencia_anual`
  ADD PRIMARY KEY (`id_vigencia`),
  ADD UNIQUE KEY `uk_agremiado_anio` (`id_agremiado`,`anio`),
  ADD KEY `registrado_por` (`registrado_por`),
  ADD KEY `idx_vigencia_anio` (`anio`),
  ADD KEY `idx_vigencia_estado` (`estado`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `afiliado`
--
ALTER TABLE `afiliado`
  MODIFY `id_afiliado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `agremiado`
--
ALTER TABLE `agremiado`
  MODIFY `id_agremiado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `beneficiario`
--
ALTER TABLE `beneficiario`
  MODIFY `id_beneficiario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `carta_aval`
--
ALTER TABLE `carta_aval`
  MODIFY `id_carta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `cuenta_web`
--
ALTER TABLE `cuenta_web`
  MODIFY `id_cuenta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `log_actividad`
--
ALTER TABLE `log_actividad`
  MODIFY `id_log` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT de la tabla `movimiento_cuenta`
--
ALTER TABLE `movimiento_cuenta`
  MODIFY `id_movimiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `recuperacion_password`
--
ALTER TABLE `recuperacion_password`
  MODIFY `id_recuperacion` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `reembolso`
--
ALTER TABLE `reembolso`
  MODIFY `id_reembolso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `solicitud_registro`
--
ALTER TABLE `solicitud_registro`
  MODIFY `id_solicitud` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `solicitud_retiro`
--
ALTER TABLE `solicitud_retiro`
  MODIFY `id_retiro` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios_registrados`
--
ALTER TABLE `usuarios_registrados`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `vigencia_anual`
--
ALTER TABLE `vigencia_anual`
  MODIFY `id_vigencia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `afiliado`
--
ALTER TABLE `afiliado`
  ADD CONSTRAINT `afiliado_ibfk_1` FOREIGN KEY (`cod_a`) REFERENCES `ipp_lutag` (`cod_a`) ON UPDATE CASCADE,
  ADD CONSTRAINT `afiliado_ibfk_2` FOREIGN KEY (`cod_pm`) REFERENCES `plan_medico` (`cod_pm`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `beneficiario`
--
ALTER TABLE `beneficiario`
  ADD CONSTRAINT `beneficiario_ibfk_1` FOREIGN KEY (`id_afiliado`) REFERENCES `afiliado` (`id_afiliado`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `carta_aval`
--
ALTER TABLE `carta_aval`
  ADD CONSTRAINT `carta_aval_ibfk_1` FOREIGN KEY (`id_afiliado`) REFERENCES `afiliado` (`id_afiliado`) ON UPDATE CASCADE,
  ADD CONSTRAINT `carta_aval_ibfk_2` FOREIGN KEY (`id_beneficiario`) REFERENCES `beneficiario` (`id_beneficiario`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `cuenta_web`
--
ALTER TABLE `cuenta_web`
  ADD CONSTRAINT `cuenta_web_ibfk_1` FOREIGN KEY (`id_agremiado`) REFERENCES `agremiado` (`id_agremiado`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `log_actividad`
--
ALTER TABLE `log_actividad`
  ADD CONSTRAINT `log_actividad_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios_registrados` (`id_usuario`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `medico`
--
ALTER TABLE `medico`
  ADD CONSTRAINT `medico_ibfk_1` FOREIGN KEY (`id_servicio`) REFERENCES `servicio` (`id_servicio`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `movimiento_cuenta`
--
ALTER TABLE `movimiento_cuenta`
  ADD CONSTRAINT `movimiento_cuenta_ibfk_1` FOREIGN KEY (`id_afiliado`) REFERENCES `afiliado` (`id_afiliado`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `plan_medico`
--
ALTER TABLE `plan_medico`
  ADD CONSTRAINT `plan_medico_ibfk_1` FOREIGN KEY (`cod_a`) REFERENCES `ipp_lutag` (`cod_a`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `recuperacion_password`
--
ALTER TABLE `recuperacion_password`
  ADD CONSTRAINT `recuperacion_password_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios_registrados` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `reembolso`
--
ALTER TABLE `reembolso`
  ADD CONSTRAINT `reembolso_ibfk_1` FOREIGN KEY (`id_afiliado`) REFERENCES `afiliado` (`id_afiliado`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `servicio`
--
ALTER TABLE `servicio`
  ADD CONSTRAINT `servicio_ibfk_1` FOREIGN KEY (`cod_pm`) REFERENCES `plan_medico` (`cod_pm`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `solicitud_registro`
--
ALTER TABLE `solicitud_registro`
  ADD CONSTRAINT `solicitud_registro_ibfk_1` FOREIGN KEY (`procesado_por`) REFERENCES `usuarios_registrados` (`id_usuario`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `solicitud_retiro`
--
ALTER TABLE `solicitud_retiro`
  ADD CONSTRAINT `solicitud_retiro_ibfk_1` FOREIGN KEY (`id_afiliado`) REFERENCES `afiliado` (`id_afiliado`) ON UPDATE CASCADE,
  ADD CONSTRAINT `solicitud_retiro_ibfk_2` FOREIGN KEY (`procesado_por`) REFERENCES `usuarios_registrados` (`id_usuario`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuarios_registrados`
--
ALTER TABLE `usuarios_registrados`
  ADD CONSTRAINT `usuarios_registrados_ibfk_1` FOREIGN KEY (`id_afiliado`) REFERENCES `afiliado` (`id_afiliado`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `usuarios_registrados_ibfk_2` FOREIGN KEY (`cod_a`) REFERENCES `ipp_lutag` (`cod_a`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `vigencia_anual`
--
ALTER TABLE `vigencia_anual`
  ADD CONSTRAINT `vigencia_anual_ibfk_1` FOREIGN KEY (`id_agremiado`) REFERENCES `agremiado` (`id_agremiado`) ON UPDATE CASCADE,
  ADD CONSTRAINT `vigencia_anual_ibfk_2` FOREIGN KEY (`registrado_por`) REFERENCES `usuarios_registrados` (`id_usuario`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
